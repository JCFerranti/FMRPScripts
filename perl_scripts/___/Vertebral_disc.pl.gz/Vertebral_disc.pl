#!/usr/bin/perl 

###############################################################
#Autor:Carlos Garrido Salmon e Rodrigo Pessini
#Ribeirao Preto,09 de dezembro de 2011      #
#versao 1 
###############################################################
#####################################################################
#@NAME       : Vertebral_disc.pl
#@INPUT      : 
#@OUTPUT     : Vertebral_Volume.txt Vertebral_ADC.txt Vertebral_FAT.txt vertebral_RELAX.txt
#@RETURNS    : 
#@DESCRIPTION: Extra��o dos dados de volume, ADC, conteudo de gordura e Relaxometria em 5 discos vertebrais.

# Modulo(Biblioteca) de acesso aos comandos do shell

use Shell; 

my $sh = Shell->new();


#***********************************************************Main************************************************************


print "\n*********************************************************************\n";
print "\n Starting Process...\n";
print "\n-- Please wait --\n";
@pastas = glob("./*");							# Guarda no ponteiro pastas as pastas no diretorio corrente
$NomePastaAnter="";							# Inicializa��o vazia da variavel NomePastaAnter
$teste = @pastas ;							# Guarda na variavel teste o numero de pastas
$contador=0;								# Inicializa��o nula da variavel contador
while($contador != $teste)						# Ciclo variando pelas diferentes pastas
{									# Inicio do ciclo das pastas
  $arquivo = $pastas[0];						# Guarda na variavel arquivo o nome da primeira pasta
  $Start = index($arquivo,"./") + 2;					# Operacao para escolher exatamente o nome
  $NomePasta = substr($arquivo,$Start);					# Define a variavel NomePasta como o nome da primeira pasta na lista
  if($NomePasta ne $NomePastaAnter)					# Condicional verificando que as variaveis NomePastaAnterior e NomePasta sao diferentes
  {  									# Inicio da condicional de NomePasta	
    print "\n ==================================================== \n"; 
    print "Patient name: ".$NomePasta."\n";				# Visualiza o nomde do paciente como pasta
	&Processamento;							# Executa a sob-routina Processamento para cada paciente
   }   									# Fim da condicional de NomePasta		
  $NomePastaAnter = $NomePasta;						# Re-define a variavel NomePastaAnterior com a atual
  shift(@pastas ); 							# Retira o primeiro elemento da lista
  $contador=$contador+1;						# Incremento do contador
}									# Fim do ciclo das pastas			


#***********************************************************Gera��o de arquivos de resultado***************************************************
 $tam =@nomes;								# Guarda na variavel teste o numero de nomes
#**************Resultados de volume*************************************
 open(RELATDADOS, "> Vertebral_Volume.txt");				# Abertura de arquivo para salvar dados de volume
 print RELATDADOS "name; V_DL1L2(cm�); V_DL2L3(cm�); V_DL3L4(cm�); V_DL4L5(cm�); VDL5S1(cm�)\n"; # Salva o cabe�alho no arquivo Vertebral_Volume.txt
 $c=0;									# Inicializa��o nula da variavel c que contabiliza os pacientes
 while($c != $tam)							# Ciclo variando pelos diferentes pacientes
	{  								# Inicio do ciclo de pacientes
	 print RELATDADOS $nomes[$c].";".$Vol_DL1L2[$c].";".$Vol_DL2L3[$c].";".$Vol_DL3L4[$c].";".$Vol_DL4L5[$c].";".$Vol_DL5S1[$c]."\n";
	 $c=$c+1;							# Incremento do contador c
	}								# Fim do ciclo de pacientes
#**************Resultados de ADC*************************************
 

 open(RELATDADOS, "> Vertebral_ADC.txt");				# Abertura de arquivo para salvar dados de ADC
 print RELATDADOS "name; ADC_DL1L2 (mm�/s); �DP(mm�/s); ADC_DL2L3 (mm�/s); �DP(mm�/s); ADC_DL3L4 (mm�/s); �DP(mm�/s); ADC_DL4L5 (mm�/s); �DP(mm�/s);   ADC_DL5S1 (mm�/s); �DP(mm�/s)\n";
 $c=0;
 while($c != $tam)
	{  
	 print RELATDADOS $nomes[$c].";".$ADC_DL1L2_mean[$c].";".$ADC_DL1L2_DP[$c].";".$ADC_DL2L3_mean[$c].";".$ADC_DL2L3_DP[$c].";".$ADC_DL3L4_mean[$c].";".$ADC_DL3L4_DP[$c].";".$ADC_DL4L5_mean[$c].";".$ADC_DL4L5_DP[$c].";".$DADC_L5S1_mean[$c].";".$DADC_L5S1_DP[$c]."\n";
	 $c=$c+1;
	}
#**************Resultados de conteudo de gordura**********************************
 open(RELATDADOS, "> Vertebral_FAT.txt");				# Abertura de arquivo para salvar dados de conteudo de gordura
 print RELATDADOS "name; FAT_DL1L2 (%); �DP(%); FAT_DL2L3 (%); �DP(%); FAT_DL3L4 (%); �DP(%); FAT_DL4L5 (%); �DP(%); FAT_DL5S1 (%); �DP(%)\n";
 $c=0;
 while($c != $tam)
	{  
	 print RELATDADOS $nomes[$c].";".$FAT_DL1L2_mean[$c].";".$FAT_DL1L2_DP[$c].";".$FAT_DL2L3_mean[$c].";".$FAT_DL2L3_DP[$c].";".$FAT_DL3L4_mean[$c].";".$FAT_DL3L4_DP[$c].";".$FAT_DL4L5_mean[$c].";".$FAT_DL4L5_DP[$c]..$FAT_DL5S1_mean[$c].";".$FAT_DL5S1_DP[$c]."\n";
	 $c=$c+1;
	}
#**************Resultados de Relaxometria**********************************
 open(RELATDADOS, "> Vertebral_RELAX.txt");				# Abertura de arquivo para salvar dados de Relaxometria
 print RELATDADOS "name; RELAX_DL1L2 (%); �DP(%); RELAX_DL2L3 (%); �DP(%); RELAX_DL3L4 (%); �DP(%); RELAX_DL4L5 (%); �DP(%) RELAX_DL5S1 (%); �DP(%)\n";
 $c=0;
 while($c != $tam)
	{  
	 print RELATDADOS $nomes[$c].";".$RELAX_DL1L2_mean[$c].";".$RELAX_DL1L2_DP[$c].";".$RELAX_DL2L3_mean[$c].";".$RELAX_DL2L3_DP[$c].";".$RELAX_DL3L4_mean[$c].";".$RELAX_DL3L4_DP[$c].";".$RELAX_DL4L5_mean[$c].";".$RELAX_DL4L5_DP[$c].$FAT_DL5S1_mean[$c].";".$FAT_DL5S1_DP[$c]."\n";
	 $c=$c+1;
	}


#********************************************Processamento******************************************************
sub Processamento   							# Inicio de sub-rotina de processamento
{
 chdir($NomePasta);							# Definindo NomePasta como sub-diretorio corrente
 @vector = glob("./*_e*");
 $file = $vector[0];
 $sh->mincheader(" $file > mincheader.txt ");
 $linha = $sh->grep(" dicom_0x0008:el_0x0020 mincheader.txt");
 $te1 = substr($linha,rindex($linha,"=")+2);
 $Stop = rindex($te1,'"');
 $te = substr($te1,0,$Stop);
 $start = index($te,'"')+1;
 $stop = index($te,'"')+4;
 $ano = substr($te,$start,$stop);
 $Start = index($te,'"')+5;
 $Stop = index($te,$ano)+1;
 $mes = substr($te,$Start,$Stop);
 $start = index($te,'"')+7;
 $stop = index($te,'"')+9;
 $dia = substr($te,$start,$stop);
 $Stop = index($NomePasta,"_");
 $Stop = index($NomePasta,"_".$ano);
 $PrimNome = substr($NomePasta,0,$Stop);
 $sh->rm(" mincheader.txt");
 push(@nomes,$PrimNome."_".$ano."_".$mes."_".$dia);
 
#************************Gera��o do mapa de conteudo de gordura***************************************************
 print"\n\n Iniciando FAT...\n\n";
 $sh->mincmath(" -double -sub ".$vector[1]." ".$vector[0]." subtracao.mnc");	# Subtracao das imagens in_phase e out_phase
 $sh->mincmath(" -double -add ".$vector[1]." ".$vector[0]." soma.mnc");		# Soma das imagens in_phase e out_phase
 $sh->mincmath(" -double -div  subtracao.mnc soma.mnc div.mnc");	# Divisao da subtracao e a soma
 $sh->mincmath(" -double -mult -const 100  div.mnc fat_map.mnc");	# Multiplicacao por 100 para levar a percentagem, criando o mapa em fat_map.mnc
 $sh->rm(" subtracao.mnc");						# Elimina o arquivo subtracao
 $sh->rm("soma.mnc");							# Elimina o arquivo soma
 $sh->rm("div.mnc");							# Elimina o arquivo div
 $sh->gzip("fat_map.mnc");						# Compactacao do arquivo com o mapa de conteudo de gordura

@label=glob("./*_lbl.mnc*");						# Guarda no ponteiro label os arquivos _label.mnc
#$sh->gzip($label[0]);							# Compacta o primeiro arquivo do ponteiro label
$arquivo = $label[0];
$Start = index($arquivo,"./") + 2;
$Stop = index($arquivo,".mnc") - 2;
$lbl = substr($arquivo,$Start,$Stop);

#************************Estimativa do volume***************************************************
#************************Volume em Disco DL1L2**********************************************************
 $sh->mincstats(" -volume ".$arquivo." -mask ".$arquivo." -mask_binvalue 1 > volume1.txt");
 $tag1 = $sh->grep(" Volume volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+7);
 $volume1 = substr($temp1,0,rindex($temp1," "));
 $volumeConv = $volume1/1000;
 $sh->rm("volume1.txt");
 push(@Vol_DL1L2,$volumeConv);
#************************Volume em Disco DL2L3**********************************************************
 $sh->mincstats(" -volume ".$arquivo." -mask ".$arquivo." -mask_binvalue 2 > volume1.txt");
 $tag1 = $sh->grep(" Volume volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+7);
 $volume1 = substr($temp1,0,rindex($temp1," "));
 $volumeConv = $volume1/1000;
 $sh->rm("volume1.txt");
 push(@Vol_DL2L3,$volumeConv);
#************************Volume em Disco DL3L4**********************************************************
 $sh->mincstats(" -volume ".$arquivo." -mask ".$arquivo." -mask_binvalue 3 > volume1.txt");
 $tag1 = $sh->grep(" Volume volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+7);
 $volume1 = substr($temp1,0,rindex($temp1," "));
 $volumeConv = $volume1/1000;
 $sh->rm("volume1.txt");
 push(@Vol_DL3L4,$volumeConv);
#************************Volume em Disco DL4L5**********************************************************
 $sh->mincstats(" -volume ".$arquivo." -mask ".$arquivo." -mask_binvalue 4 > volume1.txt");
 $tag1 = $sh->grep(" Volume volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+7);
 $volume1 = substr($temp1,0,rindex($temp1," "));
 $volumeConv = $volume1/1000;
 $sh->rm("volume1.txt");
 push(@Vol_DL4L5,$volumeConv);

#************************Volume em Disco DL5S1**********************************************************
 $sh->mincstats(" -volume ".$arquivo." -mask ".$arquivo." -mask_binvalue 5 > volume1.txt");
 $tag1 = $sh->grep(" Volume volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+7);
 $volume1 = substr($temp1,0,rindex($temp1," "));
 $volumeConv = $volume1/1000;
 $sh->rm("volume1.txt");
 push(@Vol_DL5S1,$volumeConv);

#********************Fim de estimativa do volume***************************************************

#************************Estimativa do conteudo de gordura***************************************************
# $sh->res(" ".$lbl. $PrimNome."_adc ");
# print "Result: ".$PrimNome."_adc "."\n"; 
# $sh->res(" ".$lbl. " fat_map ");				# Faz o reslice do arquivo de label em funcao do fat_map criando um novo arquivo 
 $sh->res($lbl," fat_map ");					# Faz o reslice do arquivo de label em funcao do fat_map criando um novo arquivo 
 print "lbl: ".$lbl."\n"; 

#************************Media em Disco DL1L2**********************************************************
 $sh->mincstats(" -mean fat_map.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 1 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $FAT_DL1L2_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@FAT_DL1L2_mean,$FAT_DL1L2_mean);
#************************Desvio padrao em Disco DL1L2**************************************************
 $sh->mincstats(" -stddev fat_map.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 1 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $FAT_DL1L2_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@FAT_DL1L2_DP,$FAT_DL1L2_DP);
#************************Media em Disco DL2L3********************************************************** 
 $sh->mincstats(" -mean fat_map.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 2 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $FAT_DL2L3_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@FAT_DL2L3_mean,$FAT_DL2L3_mean);
#************************Desvio padrao em Disco DL2L3**************************************************
 $sh->mincstats(" -stddev fat_map.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 2 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $FAT_DL2L3_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@FAT_DL2L3_DP,$FAT_DL2L3_DP);
#************************Media em Disco DL3L4********************************************************** 
 $sh->mincstats(" -mean fat_map.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 3 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $FAT_DL3L4_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@FAT_DL3L4_mean,$FAT_DL3L4_mean);
#************************Desvio padrao em Disco DL3L4************************************************** 
 $sh->mincstats(" -stddev fat_map.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 3 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $FAT_DL3L4_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@FAT_DL3L4_DP,$FAT_DL3L4_DP);
#************************Media em Disco DL4L5********************************************************** 
 $sh->mincstats(" -mean fat_map.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 4 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $FAT_DL4L5_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@FAT_DL4L5_mean,$FAT_DL4L5_mean);
#************************Desvio padrao em Disco DL4L5************************************************** 
 $sh->mincstats(" -stddev fat_map.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 4 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $FAT_DL4L5_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@FAT_DL4L5_DP,$FAT_DL4L5_DP);
 $sh->rm($lbl."_res.mnc.gz");					# Apaga arquivo *_res.mnc.gz
#************************Media em Disco DL5S1********************************************************** 
 $sh->mincstats(" -mean fat_map.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 5 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $FAT_DL5S1_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@FAT_DL5S1_mean,$FAT_DL5S1_mean);
#************************Desvio padrao em Disco DL5S1************************************************** 
 $sh->mincstats(" -stddev fat_map.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 5 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $FAT_DL5S1_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@FAT_DL5S1_DP,$FAT_DL5S1_DP);
 $sh->rm($lbl."_res.mnc.gz");					# Apaga arquivo *_res.mnc.gz
#*********************Fim da estimativa do conteudo de gordura*************************************************

#************************Estimativa do ADC***************************************************
 $sh->res($lbl,$PrimNome."_adc");  				# coregistra label com mapa adc
#************************Media em Disco DL1L2**********************************************************
 $sh->mincstats(" -mean ".$PrimNome."_adc.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 1 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $ADC_DL1L2_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@ADC_DL1L2_mean,$ADC_DL1L2_mean);
#************************Desvio padrao em Disco DL1L2**************************************************
 $sh->mincstats(" -stddev ".$PrimNome."_adc.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 1 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $ADC_DL1L2_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@ADC_DL1L2_DP,$ADC_DL1L2_DP);
#************************Media em Disco DL2L3********************************************************** 
 $sh->mincstats(" -mean ".$PrimNome."_adc.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 2 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $ADC_DL2L3_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@ADC_DL2L3_mean,$ADC_DL2L3_mean);
#************************Desvio padrao em Disco DL2L3**************************************************
 $sh->mincstats(" -stddev ".$PrimNome."_adc.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 2 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $ADC_DL2L3_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@ADC_DL2L3_DP,$ADC_DL2L3_DP);
#************************Media em Disco DL3L4********************************************************** 
 $sh->mincstats(" -mean ".$PrimNome."_adc.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 3 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $ADC_DL3L4_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@ADC_DL3L4_mean,$ADC_DL3L4_mean);
#************************Desvio padrao em Disco DL3L4************************************************** 
 $sh->mincstats(" -stddev ".$PrimNome."_adc.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 3 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $ADC_DL3L4_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@ADC_DL3L4_DP,$ADC_DL3L4_DP);
#************************Media em Disco DL4L5********************************************************** 
 $sh->mincstats(" -mean ".$PrimNome."_adc.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 4 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $ADC_DL4L5_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@ADC_DL4L5_mean,$ADC_DL4L5_mean);
#************************Desvio padrao em Disco DL4L5************************************************** 
 $sh->mincstats(" -stddev ".$PrimNome."_adc.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 4 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $ADC_DL4L5_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 #$sh->rm($lbl."_res.mnc.gz");						# Apaga arquivo *_res.mnc.gz
 push(@ADC_DL4L5_DP,$ADC_DL4L5_DP); 					
#************************Media em Disco DL5S1********************************************************** 
 $sh->mincstats(" -mean ".$PrimNome."_adc.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 5 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $ADC_DL5S1_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@ADC_DL5S1_mean,$ADC_DL5S1_mean);
#************************Desvio padrao em Disco DL5S1************************************************** 
 $sh->mincstats(" -stddev ".$PrimNome."_adc.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 5 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $ADC_DL5S1_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 #$sh->rm($lbl."_res.mnc.gz");
 push(@ADC_DL5S1_DP,$ADC_DL5S1_DP); 					# Apaga arquivo *_res.mnc.gz

#*********************Fim da estimativa do ADC*************************************************



#*********************Gerando a Imagem de MTR*************************************************
  
   print"\n\n 1� etapa de 6) MTR...\n\n";
  
  #$sh->mritoself(" -close ".$PrimNome."_".$ano.$mes.$dia."_0_d2.mnc.gz ".$PrimNome."_".$ano.$mes.$dia."_0_d1.mnc.gz ".$PrimNome."_".$ano.$mes.$dia."_d2tod1.xfm");
  #$sh->mincresample(" ".$PrimNome."_".$ano.$mes.$dia."_0_d2.mnc.gz ".$PrimNome."_".$ano.$mes.$dia."_d2tod1.mnc -like ".$PrimNome."_".$ano.$mes.$dia."_0_d1.mnc.gz -transformation ".$PrimNome."_".$ano.$mes.$dia."_d2tod1.xfm");
  
  $sh->mincmath(" -pd -const 10 ".$PrimNome."_".$ano.$mes.$dia."_0_d1.mnc.gz ".$PrimNome."_".$ano.$mes.$dia."_0_d2.mnc.gz ".$PrimNome."_".$ano.$mes.$dia."_mt.mnc");
 
	
	 print"\n\n Gerando Relaxo...\n\n";
	 print "\n\n".$pastas[0]."\n\n";
	 print"\n\n 1� Passo) Iniciando RelaxoN...\n\n";
     require "/usr/local/mni/scripts/relaxon.pl";
     &main; 
     $sh->mv(" relaxom.mnc ./".$PrimNome."_relaxo.mnc");
     $sh->mv(" density.mnc ./".$PrimNome."_density.mnc"); 
     $sh->gzip(" *.mnc");
	 print "\n\n".$pastas[0]."\n\n";

$sh->gzip(" *.mnc");
@label = glob("./*_lbl.mnc.gz"); 
@adc = glob("./*_adc.mnc.gz");
$sh->mv(" ".$label[0]." ./".$PrimNome."_0_lbl.mnc.gz");
$sh->mv(" ".$adc[0]." ./".$PrimNome."_0_adc.mnc.gz");




#************************Estimativa de RELAX***************************************************
print"\n\n Obtendo dados da Relaxo...\n\n";
print"\n\n relaxometria... \n\n";  
$sh->res($lbl,$PrimNome."_relaxo");  				# coregistra label com relax
#************************Media em Disco DL1L2**********************************************************
 $sh->mincstats(" -mean ".$PrimNome."_relaxo.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 1 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $RELAX_DL1L2_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@RELAX_DL1L2_mean,$RELAX_DL1L2_mean);
#************************Desvio padrao em Disco DL1L2**************************************************
 $sh->mincstats(" -stddev ".$PrimNome."_relaxo.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 1 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $RELAX_DL1L2_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@RELAX_DL1L2_DP,$RELAX_DL1L2_DP);
#************************Media em Disco DL2L3********************************************************** 
 $sh->mincstats(" -mean ".$PrimNome."_relaxo.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 2 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $RELAX_DL2L3_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@RELAX_DL2L3_mean,$RELAX_DL2L3_mean);
#************************Desvio padrao em Disco DL2L3**************************************************
 $sh->mincstats(" -stddev ".$PrimNome."_relaxo.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 2 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $RELAX_DL2L3_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@RELAX_DL2L3_DP,$RELAX_DL2L3_DP);
#************************Media em Disco DL3L4********************************************************** 
 $sh->mincstats(" -mean ".$PrimNome."_relaxo.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 3 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $RELAX_DL3L4_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@RELAX_DL3L4_mean,$RELAX_DL3L4_mean);
#************************Desvio padrao em Disco DL3L4************************************************** 
 $sh->mincstats(" -stddev ".$PrimNome."_relaxo.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 3 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $RELAX_DL3L4_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@RELAX_DL3L4_DP,$RELAX_DL3L4_DP);
#************************Media em Disco DL4L5********************************************************** 
 $sh->mincstats(" -mean ".$PrimNome."_relaxo.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 4 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $RELAX_DL4L5_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@RELAX_DL4L5_mean,$RELAX_DL4L5_mean);
#************************Desvio padrao em Disco DL4L5************************************************** 
 $sh->mincstats(" -stddev ".$PrimNome."_relaxo.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 4 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $RELAX_DL4L5_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 $sh->rm($lbl."_res.mnc.gz");						# Apaga arquivo *_res.mnc.gz
 push(@RELAX_DL4L5_DP,$RELAX_DL4L5_DP); 					
#************************Media em Disco DL5S1********************************************************** 
 $sh->mincstats(" -mean ".$PrimNome."_relaxo.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 5 > volume1.txt");
 $tag1 = $sh->grep(" Mean volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+15);
 $RELAX_DL5S1_mean = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 push(@RELAX_DL5S1_mean,$RELAX_DL5S1_mean);
#************************Desvio padrao em Disco DL5S1************************************************** 
 $sh->mincstats(" -stddev ".$PrimNome."_relaxo.mnc.gz -mask ".$lbl."_res.mnc.gz -mask_binvalue 5 > volume1.txt");
 $tag1 = $sh->grep(" Stddev volume1.txt");
 $temp1 = substr($tag1,rindex($tag1,":")+13);
 $RELAX_DL5S1_DP = substr($temp1,0,rindex($temp1," "));
 $sh->rm("volume1.txt");
 #$sh->rm($lbl."_res.mnc.gz");
 push(@RELAX_DL5S1_DP,$RELAX_DL5S1_DP); 					# Apaga arquivo *_res.mnc.gz

#*********************Fim da estimativa de RELAX*************************************************





 chdir("..");							# Deixa no diretorio inicial		
}								# Fim do programa principal


